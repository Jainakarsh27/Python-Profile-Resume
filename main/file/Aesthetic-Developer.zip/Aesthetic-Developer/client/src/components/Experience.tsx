import { motion } from "framer-motion";
import { useExperience } from "@/hooks/use-portfolio";
import { Briefcase } from "lucide-react";

export function Experience() {
  const { data: experiences } = useExperience();

  if (!experiences || experiences.length === 0) return null;

  // Sort by order
  const sortedExperiences = [...experiences].sort((a, b) => a.order - b.order);

  return (
    <section id="experience" className="py-24 relative">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex items-center gap-4 mb-16 max-w-4xl mx-auto"
        >
          <span className="font-mono text-secondary text-xl">02.</span>
          <h2 className="text-3xl md:text-5xl font-display font-bold">Experience</h2>
          <div className="h-[1px] bg-white/10 flex-grow ml-4"></div>
        </motion.div>

        <div className="max-w-3xl mx-auto">
          {sortedExperiences.map((exp, index) => (
            <motion.div
              key={exp.id}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="relative pl-8 md:pl-0"
            >
              {/* Timeline connector line for desktop */}
              <div className="hidden md:block absolute left-[50%] top-0 bottom-0 w-[1px] bg-white/10 -translate-x-1/2 last:bottom-auto last:h-full" />
              
              <div className={`md:flex items-start justify-between gap-12 group mb-12 relative ${
                index % 2 === 0 ? "md:flex-row-reverse" : ""
              }`}>
                {/* Timeline Dot */}
                <div className="absolute left-[-29px] md:left-1/2 top-1 w-4 h-4 rounded-full bg-background border-2 border-primary z-10 md:-translate-x-1/2 group-hover:scale-125 group-hover:bg-primary transition-all duration-300 shadow-[0_0_10px_rgba(112,0,255,0.5)]" />

                {/* Date */}
                <div className={`md:w-1/2 mb-2 md:mb-0 ${index % 2 === 0 ? "md:text-left" : "md:text-right"}`}>
                  <span className="font-mono text-sm text-secondary/80 bg-secondary/5 px-3 py-1 rounded-full border border-secondary/20">
                    {exp.duration}
                  </span>
                </div>

                {/* Content Card */}
                <div className={`md:w-1/2 ${index % 2 === 0 ? "md:text-right" : "md:text-left"}`}>
                  <div className="glass-card p-6 rounded-2xl relative hover:-translate-y-1 transition-transform duration-300">
                    <h3 className="text-xl font-bold text-foreground mb-1">{exp.role}</h3>
                    <p className="text-primary font-medium mb-4 flex items-center gap-2 md:inline-flex">
                      <Briefcase className="w-4 h-4" />
                      {exp.company}
                    </p>
                    <p className="text-muted-foreground text-sm leading-relaxed whitespace-pre-line">
                      {exp.description}
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
