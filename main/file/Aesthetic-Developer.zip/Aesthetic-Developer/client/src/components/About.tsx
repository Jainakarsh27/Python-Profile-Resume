import { motion } from "framer-motion";
import { useProfile } from "@/hooks/use-portfolio";

export function About() {
  const { data: profile } = useProfile();

  if (!profile) return null;

  return (
    <section id="about" className="py-24 relative overflow-hidden">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="max-w-4xl mx-auto"
        >
          <div className="flex items-center gap-4 mb-12">
            <span className="font-mono text-primary text-xl">01.</span>
            <h2 className="text-3xl md:text-5xl font-display font-bold">About Me</h2>
            <div className="h-[1px] bg-white/10 flex-grow ml-4"></div>
          </div>

          <div className="grid md:grid-cols-5 gap-12">
            <div className="md:col-span-3 text-lg text-muted-foreground leading-relaxed space-y-6">
              <div dangerouslySetInnerHTML={{ __html: profile.about.replace(/\n/g, '<br/>') }} />
            </div>

            <div className="md:col-span-2">
              <div className="relative group">
                {/* Decorative border frame */}
                <div className="absolute inset-0 border-2 border-primary/30 rounded-2xl translate-x-4 translate-y-4 group-hover:translate-x-2 group-hover:translate-y-2 transition-transform duration-300" />
                
                {/* Image container */}
                <div className="relative rounded-2xl overflow-hidden glass-panel aspect-[4/5] bg-muted flex items-center justify-center">
                  {/* Placeholder for avatar/profile image if API supported it, using standard icon or gradient for now */}
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-background to-secondary/20" />
                  <span className="text-8xl font-display font-bold opacity-10 select-none">
                    {profile.name.charAt(0)}
                  </span>
                  
                  {/* Overlay for glass effect */}
                  <div className="absolute inset-0 hover:bg-primary/10 transition-colors duration-300" />
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
