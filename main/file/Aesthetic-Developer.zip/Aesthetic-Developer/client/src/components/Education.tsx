import { motion } from "framer-motion";
import { useEducation, useCertifications } from "@/hooks/use-portfolio";
import { GraduationCap, Award } from "lucide-react";

export function Education() {
  const { data: education } = useEducation();
  const { data: certifications } = useCertifications();

  if (!education && !certifications) return null;

  return (
    <section className="py-24 relative bg-black/20">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 max-w-6xl mx-auto">
          {/* Education Column */}
          {education && education.length > 0 && (
            <div>
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="flex items-center gap-4 mb-8"
              >
                <GraduationCap className="w-8 h-8 text-secondary" />
                <h3 className="text-2xl font-display font-bold">Education</h3>
              </motion.div>

              <div className="space-y-6">
                {education.map((edu, idx) => (
                  <motion.div
                    key={edu.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.1 }}
                    className="glass-card p-6 rounded-xl border-l-4 border-l-secondary"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="text-lg font-bold">{edu.university}</h4>
                      <span className="text-xs font-mono text-secondary px-2 py-1 rounded bg-secondary/10">
                        {edu.duration}
                      </span>
                    </div>
                    <p className="text-muted-foreground mb-1">{edu.degree}</p>
                    {edu.cgpa && <p className="text-sm text-muted-foreground/60">CGPA: {edu.cgpa}</p>}
                  </motion.div>
                ))}
              </div>
            </div>
          )}

          {/* Certifications Column */}
          {certifications && certifications.length > 0 && (
            <div>
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="flex items-center gap-4 mb-8"
              >
                <Award className="w-8 h-8 text-accent" />
                <h3 className="text-2xl font-display font-bold">Certifications</h3>
              </motion.div>

              <div className="space-y-4">
                {certifications.map((cert, idx) => (
                  <motion.div
                    key={cert.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.1 }}
                    className="glass-panel p-4 rounded-xl flex items-center justify-between hover:bg-white/5 transition-colors group"
                  >
                    <div>
                      <h4 className="font-bold group-hover:text-accent transition-colors">{cert.name}</h4>
                      <p className="text-sm text-muted-foreground">{cert.issuer}</p>
                    </div>
                    <span className="text-sm font-mono text-muted-foreground/60">{cert.year}</span>
                  </motion.div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
