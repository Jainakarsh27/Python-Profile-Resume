import { motion } from "framer-motion";
import { useSkills } from "@/hooks/use-portfolio";

export function Skills() {
  const { data: skills } = useSkills();

  if (!skills || skills.length === 0) return null;

  const sortedSkills = [...skills].sort((a, b) => a.order - b.order);

  return (
    <section id="skills" className="py-24 relative">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex items-center gap-4 mb-16 max-w-4xl mx-auto"
        >
          <span className="font-mono text-primary text-xl">04.</span>
          <h2 className="text-3xl md:text-5xl font-display font-bold">Tech Stack</h2>
          <div className="h-[1px] bg-white/10 flex-grow ml-4"></div>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          {sortedSkills.map((skillGroup, index) => (
            <motion.div
              key={skillGroup.id}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="glass-panel p-6 rounded-2xl hover:border-primary/30 transition-colors"
            >
              <h3 className="text-xl font-bold mb-6 text-center text-gradient">
                {skillGroup.category}
              </h3>
              <div className="flex flex-wrap gap-2 justify-center">
                {skillGroup.items.map((item) => (
                  <span
                    key={item}
                    className="px-3 py-1.5 rounded-md bg-white/5 border border-white/5 text-sm text-muted-foreground hover:text-white hover:border-primary/50 hover:bg-primary/10 transition-all cursor-default"
                  >
                    {item}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
