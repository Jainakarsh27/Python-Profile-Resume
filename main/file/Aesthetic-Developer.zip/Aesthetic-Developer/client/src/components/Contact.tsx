import { motion } from "framer-motion";
import { useProfile, useSocialLinks } from "@/hooks/use-portfolio";
import { Mail, Github, Linkedin, ExternalLink } from "lucide-react";

export function Contact() {
  const { data: profile } = useProfile();
  const { data: socialLinks } = useSocialLinks();

  const getIcon = (platform: string) => {
    switch (platform.toLowerCase()) {
      case 'github': return <Github className="w-6 h-6" />;
      case 'linkedin': return <Linkedin className="w-6 h-6" />;
      default: return <ExternalLink className="w-6 h-6" />;
    }
  };

  return (
    <section id="contact" className="py-32 relative text-center">
      <div className="container mx-auto px-6 max-w-2xl">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
        >
          <span className="font-mono text-secondary mb-4 block">05. What's Next?</span>
          <h2 className="text-5xl md:text-6xl font-display font-bold mb-6">Get In Touch</h2>
          
          <p className="text-lg text-muted-foreground mb-12 leading-relaxed">
            I'm currently looking for new opportunities. Whether you have a question, 
            a project idea, or just want to say hi, I'll try my best to get back to you!
          </p>

          <a
            href={`mailto:${profile?.email}`}
            className="inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-transparent border-2 border-primary text-primary font-bold hover:bg-primary/10 transition-all hover:-translate-y-1 mb-16"
          >
            <Mail className="w-5 h-5" />
            Say Hello
          </a>

          {/* Footer Links */}
          <div className="flex justify-center gap-8 mb-8">
            {socialLinks?.map((link) => (
              <a
                key={link.id}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-secondary hover:-translate-y-1 transition-all"
              >
                {getIcon(link.platform)}
              </a>
            ))}
          </div>

          <p className="font-mono text-xs text-muted-foreground/50">
            Designed & Built by {profile?.name || "Web Developer"}
          </p>
        </motion.div>
      </div>
    </section>
  );
}
