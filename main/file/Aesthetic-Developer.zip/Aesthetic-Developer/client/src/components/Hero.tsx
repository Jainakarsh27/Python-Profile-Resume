import { motion } from "framer-motion";
import { Typewriter } from "react-simple-typewriter";
import { ArrowDown, Github, Linkedin, Mail, FileText } from "lucide-react";
import { useProfile, useSocialLinks } from "@/hooks/use-portfolio";

export function Hero() {
  const { data: profile } = useProfile();
  const { data: socialLinks } = useSocialLinks();

  const getIcon = (platform: string) => {
    switch (platform.toLowerCase()) {
      case 'github': return <Github className="w-5 h-5" />;
      case 'linkedin': return <Linkedin className="w-5 h-5" />;
      default: return <FileText className="w-5 h-5" />;
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden">
      {/* Background Ambience */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-primary/20 rounded-full blur-[120px] animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[600px] h-[600px] bg-secondary/10 rounded-full blur-[120px] animate-pulse delay-1000" />
        <div className="absolute top-[40%] left-[60%] w-[300px] h-[300px] bg-accent/10 rounded-full blur-[100px]" />
        
        {/* Grid Pattern Overlay */}
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="flex flex-col items-start max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <span className="font-mono text-secondary mb-4 block text-lg">
              Hello, world. I am
            </span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-6xl md:text-8xl font-display font-bold tracking-tight mb-6"
          >
            <span className="text-foreground">{profile?.name || "Loading..."}</span>
            <br />
            <span className="text-gradient opacity-90">
              {profile?.title || "Web Developer"}
            </span>
          </motion.h1>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl md:text-2xl text-muted-foreground mb-8 h-8 font-mono"
          >
            I build{" "}
            <span className="text-white">
              <Typewriter
                words={['digital experiences.', 'scalable applications.', 'beautiful interfaces.', 'future tech.']}
                loop={0}
                cursor
                cursorStyle='_'
                typeSpeed={70}
                deleteSpeed={50}
                delaySpeed={1000}
              />
            </span>
          </motion.div>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="text-lg text-muted-foreground max-w-2xl mb-10 leading-relaxed"
          >
            {profile?.subtitle || "Crafting exceptional digital experiences with clean code and modern design principles. Specialized in full-stack development and UI/UX design."}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="flex flex-wrap gap-4"
          >
            <a 
              href="#contact"
              className="px-8 py-4 rounded-xl bg-primary hover:bg-primary/90 text-white font-semibold shadow-lg shadow-primary/25 hover:shadow-primary/40 hover:-translate-y-1 transition-all duration-300"
            >
              Contact Me
            </a>
            
            <div className="flex items-center gap-4 ml-4">
              {socialLinks?.map((link, idx) => (
                <a
                  key={link.id}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 rounded-xl glass-panel hover:bg-white/10 text-muted-foreground hover:text-secondary transition-all hover:scale-110"
                >
                  {getIcon(link.platform)}
                </a>
              ))}
              <a
                href={`mailto:${profile?.email}`}
                className="p-3 rounded-xl glass-panel hover:bg-white/10 text-muted-foreground hover:text-secondary transition-all hover:scale-110"
              >
                <Mail className="w-5 h-5" />
              </a>
            </div>
          </motion.div>
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce"
      >
        <a href="#about" className="p-2 rounded-full hover:bg-white/5 transition-colors">
          <ArrowDown className="w-6 h-6 text-muted-foreground" />
        </a>
      </motion.div>
    </section>
  );
}
