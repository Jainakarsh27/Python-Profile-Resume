import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";

// Hook to fetch Profile
export function useProfile() {
  return useQuery({
    queryKey: [api.profile.get.path],
    queryFn: async () => {
      const res = await fetch(api.profile.get.path);
      if (!res.ok) throw new Error("Failed to fetch profile");
      return api.profile.get.responses[200].parse(await res.json());
    },
  });
}

// Hook to fetch Experience
export function useExperience() {
  return useQuery({
    queryKey: [api.experience.list.path],
    queryFn: async () => {
      const res = await fetch(api.experience.list.path);
      if (!res.ok) throw new Error("Failed to fetch experience");
      const data = await res.json();
      return api.experience.list.responses[200].parse(data);
    },
  });
}

// Hook to fetch Projects
export function useProjects() {
  return useQuery({
    queryKey: [api.projects.list.path],
    queryFn: async () => {
      const res = await fetch(api.projects.list.path);
      if (!res.ok) throw new Error("Failed to fetch projects");
      return api.projects.list.responses[200].parse(await res.json());
    },
  });
}

// Hook to fetch Skills
export function useSkills() {
  return useQuery({
    queryKey: [api.skills.list.path],
    queryFn: async () => {
      const res = await fetch(api.skills.list.path);
      if (!res.ok) throw new Error("Failed to fetch skills");
      return api.skills.list.responses[200].parse(await res.json());
    },
  });
}

// Hook to fetch Education
export function useEducation() {
  return useQuery({
    queryKey: [api.education.list.path],
    queryFn: async () => {
      const res = await fetch(api.education.list.path);
      if (!res.ok) throw new Error("Failed to fetch education");
      return api.education.list.responses[200].parse(await res.json());
    },
  });
}

// Hook to fetch Certifications
export function useCertifications() {
  return useQuery({
    queryKey: [api.certifications.list.path],
    queryFn: async () => {
      const res = await fetch(api.certifications.list.path);
      if (!res.ok) throw new Error("Failed to fetch certifications");
      return api.certifications.list.responses[200].parse(await res.json());
    },
  });
}

// Hook to fetch Achievements
export function useAchievements() {
  return useQuery({
    queryKey: [api.achievements.list.path],
    queryFn: async () => {
      const res = await fetch(api.achievements.list.path);
      if (!res.ok) throw new Error("Failed to fetch achievements");
      return api.achievements.list.responses[200].parse(await res.json());
    },
  });
}

// Hook to fetch Social Links
export function useSocialLinks() {
  return useQuery({
    queryKey: [api.socialLinks.list.path],
    queryFn: async () => {
      const res = await fetch(api.socialLinks.list.path);
      if (!res.ok) throw new Error("Failed to fetch social links");
      return api.socialLinks.list.responses[200].parse(await res.json());
    },
  });
}
