import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { 
  User, Briefcase, Rocket, Brain, GraduationCap, 
  Award, FileBadge, Mail, Github, Linkedin, ExternalLink 
} from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { 
  Profile, Experience, Project, Skill, Education, 
  Certification, Achievement, SocialLink 
} from "@shared/schema";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
};

export default function Dashboard() {
  const { data: profile } = useQuery<Profile>({ queryKey: ["/api/profile"] });
  const { data: experiences } = useQuery<Experience[]>({ queryKey: ["/api/experience"] });
  const { data: projects } = useQuery<Project[]>({ queryKey: ["/api/projects"] });
  const { data: skills } = useQuery<Skill[]>({ queryKey: ["/api/skills"] });
  const { data: education } = useQuery<Education[]>({ queryKey: ["/api/education"] });
  const { data: certs } = useQuery<Certification[]>({ queryKey: ["/api/certifications"] });
  const { data: achievements } = useQuery<Achievement[]>({ queryKey: ["/api/achievements"] });
  const { data: socials } = useQuery<SocialLink[]>({ queryKey: ["/api/social-links"] });

  return (
    <div className="min-h-screen bg-black text-gray-100 p-6 md:p-12">
      <div className="max-w-6xl mx-auto space-y-24">
        
        {/* Header */}
        <header className="flex flex-col items-center text-center space-y-4">
          <motion.h1 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-4xl md:text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-purple-500"
          >
            Akarsh Jain — Developer Portfolio
          </motion.h1>
          <p className="text-xl text-gray-400 max-w-2xl">
            Building scalable systems, clean interfaces, and AI-powered solutions.
          </p>
        </header>

        <motion.div 
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 gap-8"
        >
          {/* About Section */}
          <motion.div variants={item} className="md:col-span-2">
            <Card className="bg-white/5 border-white/10 backdrop-blur-xl">
              <CardHeader className="flex flex-row items-center gap-4">
                <User className="w-8 h-8 text-cyan-400" />
                <CardTitle className="text-2xl font-bold">About Akarsh</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-lg leading-relaxed text-gray-300">
                  {profile?.about}
                </p>
              </CardContent>
            </Card>
          </motion.div>

          {/* Experience Section */}
          <motion.div variants={item}>
            <Card className="bg-white/5 border-white/10 backdrop-blur-xl h-full">
              <CardHeader className="flex flex-row items-center gap-4">
                <Briefcase className="w-8 h-8 text-purple-400" />
                <CardTitle className="text-2xl font-bold">Experience</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {experiences?.map((exp) => (
                  <div key={exp.id} className="border-l-2 border-purple-500/30 pl-4 py-2">
                    <h3 className="text-xl font-bold text-gray-100">{exp.role}</h3>
                    <p className="text-purple-400 font-medium">{exp.company}</p>
                    <p className="text-sm text-gray-500 mb-2">{exp.duration}</p>
                    <p className="text-gray-400">{exp.description}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          </motion.div>

          {/* Education Section */}
          <motion.div variants={item}>
            <Card className="bg-white/5 border-white/10 backdrop-blur-xl h-full">
              <CardHeader className="flex flex-row items-center gap-4">
                <GraduationCap className="w-8 h-8 text-cyan-400" />
                <CardTitle className="text-2xl font-bold">Academic Background</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {education?.map((edu) => (
                  <div key={edu.id}>
                    <h3 className="text-xl font-bold text-gray-100">{edu.degree}</h3>
                    <p className="text-cyan-400 font-medium">{edu.university}</p>
                    <div className="flex justify-between text-sm text-gray-500 mt-2">
                      <span>{edu.duration}</span>
                      <span>CGPA: {edu.cgpa}</span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </motion.div>

          {/* Projects Section */}
          <motion.div variants={item} className="md:col-span-2">
            <div className="flex items-center gap-4 mb-8">
              <Rocket className="w-8 h-8 text-orange-400" />
              <h2 className="text-3xl font-bold">Featured Projects</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {projects?.map((project) => (
                <Card key={project.id} className="bg-white/5 border-white/10 backdrop-blur-xl hover:border-cyan-500/50 transition-colors group">
                  <CardHeader>
                    <CardTitle className="text-2xl font-bold text-white group-hover:text-cyan-400 transition-colors">
                      {project.title}
                    </CardTitle>
                    <p className="text-cyan-400/80 font-medium">{project.subtitle}</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-gray-400">{project.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {project.techStack?.map((tech) => (
                        <Badge key={tech} variant="outline" className="border-cyan-500/30 text-cyan-400">
                          {tech}
                        </Badge>
                      ))}
                    </div>
                    <ul className="space-y-2">
                      {project.highlights?.map((highlight, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm text-gray-400">
                          <span className="text-cyan-500 mt-1">•</span>
                          {highlight}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
          </motion.div>

          {/* Tech Stack Grid */}
          <motion.div variants={item} className="md:col-span-2">
            <div className="flex items-center gap-4 mb-8">
              <Brain className="w-8 h-8 text-green-400" />
              <h2 className="text-3xl font-bold">Tech Stack</h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {skills?.map((skill) => (
                <Card key={skill.id} className="bg-white/5 border-white/10 backdrop-blur-xl">
                  <CardHeader>
                    <CardTitle className="text-xl font-bold text-green-400">{skill.category}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      {skill.items?.map((s) => (
                        <Badge key={s} className="bg-green-500/10 text-green-400 border-none">
                          {s}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </motion.div>

          {/* Certifications & Achievements */}
          <motion.div variants={item}>
            <Card className="bg-white/5 border-white/10 backdrop-blur-xl h-full">
              <CardHeader className="flex flex-row items-center gap-4">
                <FileBadge className="w-8 h-8 text-yellow-400" />
                <CardTitle className="text-2xl font-bold">Certifications</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {certs?.map((cert) => (
                  <div key={cert.id} className="flex justify-between items-center group">
                    <span className="text-gray-300 group-hover:text-white transition-colors">{cert.name}</span>
                    <Badge variant="secondary" className="bg-white/5 text-gray-500">{cert.issuer}</Badge>
                  </div>
                ))}
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={item}>
            <Card className="bg-white/5 border-white/10 backdrop-blur-xl h-full">
              <CardHeader className="flex flex-row items-center gap-4">
                <Award className="w-8 h-8 text-red-400" />
                <CardTitle className="text-2xl font-bold">Achievements</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {achievements?.map((ach) => (
                  <div key={ach.id} className="flex gap-3 text-gray-300">
                    <span className="text-red-500">•</span>
                    {ach.description}
                  </div>
                ))}
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>

        {/* Footer / Connect */}
        <footer className="pt-12 border-t border-white/10">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="text-center md:text-left">
              <h2 className="text-3xl font-bold mb-2">Let’s build something meaningful together.</h2>
              <p className="text-gray-400">Available for internships, collaborations, and innovative projects.</p>
            </div>
            <div className="flex gap-4">
              {socials?.map((social) => (
                <Button 
                  key={social.id}
                  variant="outline" 
                  size="icon"
                  className="w-12 h-12 rounded-full border-white/10 hover:border-cyan-500 hover:text-cyan-400 transition-all bg-white/5"
                  asChild
                >
                  <a href={social.url} target="_blank" rel="noopener noreferrer">
                    {social.platform === "LinkedIn" && <Linkedin className="w-5 h-5" />}
                    {social.platform === "GitHub" && <Github className="w-5 h-5" />}
                    {social.platform === "Email" && <Mail className="w-5 h-5" />}
                  </a>
                </Button>
              ))}
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
