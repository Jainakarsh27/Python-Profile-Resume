## Packages
framer-motion | Complex animations and page transitions
react-simple-typewriter | Typing effect for hero section
react-icons | Additional icon sets beyond Lucide

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
  mono: ["var(--font-mono)"],
}
