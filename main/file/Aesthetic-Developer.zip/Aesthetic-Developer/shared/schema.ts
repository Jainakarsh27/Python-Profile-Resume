import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===

// Profile/Bio Section
export const profile = pgTable("profile", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  title: text("title").notNull(),
  subtitle: text("subtitle").notNull(),
  about: text("about").notNull(),
  resumeUrl: text("resume_url"),
  email: text("email"),
});

// Experience Section
export const experience = pgTable("experience", {
  id: serial("id").primaryKey(),
  role: text("role").notNull(),
  company: text("company").notNull(),
  duration: text("duration").notNull(),
  description: text("description").notNull(), // Can store bullet points as newlines or JSON array if preferred, text is simpler
  order: integer("order").notNull(), // For display order
});

// Projects Section
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  subtitle: text("subtitle"),
  description: text("description").notNull(),
  techStack: jsonb("tech_stack").$type<string[]>().notNull(), // Array of strings
  highlights: jsonb("highlights").$type<string[]>().notNull(), // Array of bullet points
  link: text("link"),
  githubLink: text("github_link"),
  order: integer("order").notNull(),
});

// Skills/Tech Stack Section
export const skills = pgTable("skills", {
  id: serial("id").primaryKey(),
  category: text("category").notNull(), // Frontend, Backend, AI, Tools
  items: jsonb("items").$type<string[]>().notNull(),
  order: integer("order").notNull(),
});

// Education Section
export const education = pgTable("education", {
  id: serial("id").primaryKey(),
  degree: text("degree").notNull(),
  university: text("university").notNull(),
  duration: text("duration").notNull(),
  cgpa: text("cgpa"),
  order: integer("order").notNull(),
});

// Certifications Section
export const certifications = pgTable("certifications", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  issuer: text("issuer"),
  year: text("year"),
});

// Achievements
export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  description: text("description").notNull(),
});

// Social Links
export const socialLinks = pgTable("social_links", {
  id: serial("id").primaryKey(),
  platform: text("platform").notNull(), // LinkedIn, GitHub, etc.
  url: text("url").notNull(),
  icon: text("icon").notNull(), // Icon name for frontend to map
});


// === INSERT SCHEMAS ===
export const insertProfileSchema = createInsertSchema(profile).omit({ id: true });
export const insertExperienceSchema = createInsertSchema(experience).omit({ id: true });
export const insertProjectSchema = createInsertSchema(projects).omit({ id: true });
export const insertSkillSchema = createInsertSchema(skills).omit({ id: true });
export const insertEducationSchema = createInsertSchema(education).omit({ id: true });
export const insertCertificationSchema = createInsertSchema(certifications).omit({ id: true });
export const insertAchievementSchema = createInsertSchema(achievements).omit({ id: true });
export const insertSocialLinkSchema = createInsertSchema(socialLinks).omit({ id: true });

// === TYPES ===
export type Profile = typeof profile.$inferSelect;
export type Experience = typeof experience.$inferSelect;
export type Project = typeof projects.$inferSelect;
export type Skill = typeof skills.$inferSelect;
export type Education = typeof education.$inferSelect;
export type Certification = typeof certifications.$inferSelect;
export type Achievement = typeof achievements.$inferSelect;
export type SocialLink = typeof socialLinks.$inferSelect;
