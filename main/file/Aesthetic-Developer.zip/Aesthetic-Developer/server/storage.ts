import { db } from "./db";
import {
  profile, experience, projects, skills, education, certifications, achievements, socialLinks,
  type Profile, type Experience, type Project, type Skill, type Education, type Certification, type Achievement, type SocialLink
} from "@shared/schema";
import { asc, desc } from "drizzle-orm";

export interface IStorage {
  getProfile(): Promise<Profile | undefined>;
  getExperience(): Promise<Experience[]>;
  getProjects(): Promise<Project[]>;
  getSkills(): Promise<Skill[]>;
  getEducation(): Promise<Education[]>;
  getCertifications(): Promise<Certification[]>;
  getAchievements(): Promise<Achievement[]>;
  getSocialLinks(): Promise<SocialLink[]>;
  
  // Seed methods (internal use mainly)
  seedData(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getProfile(): Promise<Profile | undefined> {
    const result = await db.select().from(profile).limit(1);
    return result[0];
  }

  async getExperience(): Promise<Experience[]> {
    return await db.select().from(experience).orderBy(asc(experience.order));
  }

  async getProjects(): Promise<Project[]> {
    return await db.select().from(projects).orderBy(asc(projects.order));
  }

  async getSkills(): Promise<Skill[]> {
    return await db.select().from(skills).orderBy(asc(skills.order));
  }

  async getEducation(): Promise<Education[]> {
    return await db.select().from(education).orderBy(asc(education.order));
  }

  async getCertifications(): Promise<Certification[]> {
    return await db.select().from(certifications);
  }

  async getAchievements(): Promise<Achievement[]> {
    return await db.select().from(achievements);
  }

  async getSocialLinks(): Promise<SocialLink[]> {
    return await db.select().from(socialLinks);
  }

  async seedData(): Promise<void> {
    // Check if data exists
    const existing = await this.getProfile();
    if (existing) return;

    // Seed Profile
    await db.insert(profile).values({
      name: "Akarsh Jain",
      title: "Web Developer | Software Engineer | AI-Driven Thinker",
      subtitle: "Designing meaningful digital experiences with code, creativity, and intelligence.",
      about: "Akarsh Jain is a Computer Science undergraduate at VIT Bhopal, driven by a deep passion for web development, system design, and AI-powered applications. With hands-on experience across frontend, backend, cloud, and generative AI, he focuses on building clean, scalable, and user-centric digital products. He believes great software is not just functional — it is intuitive, performant, and thoughtfully designed. Currently working as a Software Development Intern, Akarsh actively contributes to real-world production systems while continuously experimenting with modern tech stacks, UI/UX patterns, and AI integrations.",
      resumeUrl: "#", // Placeholder
      email: "contact@akarshjain.dev" // Placeholder based on context
    });

    // Seed Experience
    await db.insert(experience).values([
      {
        role: "Software Development Intern",
        company: "Femira (by Meraji)",
        duration: "Jan 2026 – Present",
        description: "Working across frontend and backend modules. Feature development, debugging, optimization. Agile SDLC workflows (sprints, testing, deployments). Automation scripts & system efficiency improvements. Git & GitHub collaboration on production codebases.",
        order: 1
      },
      {
        role: "Virtual Intern — Generative AI",
        company: "Google Cloud (SmartBridge & SmartInternz)",
        duration: "Nov 2025 – Jan 2026",
        description: "Learned LLMs, prompt engineering, tokenization. Built hands-on AI solutions using Google Cloud tools. Worked on conversational AI & content generation use cases. Explored cloud deployment & scalability concepts.",
        order: 2
      }
    ]);

    // Seed Projects
    await db.insert(projects).values([
      {
        title: "Project Synapse",
        subtitle: "AI-Powered Last-Mile Delivery Platform",
        description: "A comprehensive delivery platform featuring role-based dashboards, live tracking, and AI support. Significantly modified the hosting model for improved scalability and deployment efficiency.",
        techStack: ["React.js", "Tailwind CSS", "REST APIs", "SQLModel", "Leaflet.js", "AWS/Cloud"],
        highlights: [
          "Role-based dashboards (customer & rider)",
          "Live order tracking with maps",
          "AI chatbot for issue resolution",
          "Optimized hosting architecture",
          "Clean, scalable UI design"
        ],
        order: 1
      },
      {
        title: "Government Schemes Portal",
        subtitle: "Citizen Information & Eligibility System",
        description: "A professional platform designed to help citizens explore, verify eligibility, and apply for various government welfare schemes in a streamlined manner.",
        techStack: ["React.js", "Node.js", "PostgreSQL", "Tailwind CSS"],
        highlights: [
          "Eligibility checking algorithm based on user profile",
          "Multi-language support for accessibility",
          "Secure document management and tracking",
          "Integration with government API endpoints"
        ],
        order: 2
      },
      {
        title: "MEDIBOT",
        subtitle: "Healthcare AI-Enabled Teleconsultation Platform",
        description: "A healthcare-focused platform for symptom assessment and teleconsultation, leveraging AI for preliminary health guidance and patient-centric design.",
        techStack: ["React.js", "Tailwind CSS", "AI/NLP concepts", "WebRTC"],
        highlights: [
          "Symptom-based health assessment",
          "Accessible, responsive healthcare UI",
          "Modular and clean frontend components",
          "Secure teleconsultation features"
        ],
        order: 3
      },
      {
        title: "Sahayak AI",
        subtitle: "Intelligent AI Assistance System",
        description: "An intelligent assistant system focusing on intent detection and context-aware responses to improve user interaction flows.",
        techStack: ["Python", "NLP", "AI Models", "REST APIs"],
        highlights: [
          "NLP-based intent detection",
          "Context-aware conversational responses",
          "Automated guidance logic",
          "Focus on accuracy, flow, and usability"
        ],
        order: 4
      }
    ]);

    // Seed Skills
    await db.insert(skills).values([
      { category: "Frontend", items: ["HTML5", "CSS3", "JavaScript (ES6+)", "React.js", "Tailwind CSS"], order: 1 },
      { category: "Backend & APIs", items: ["REST APIs", "FastAPI (basic)", "JSON"], order: 2 },
      { category: "AI & Cloud", items: ["Generative AI", "Prompt Engineering", "AWS (EC2, S3, IAM)", "Google Cloud"], order: 3 },
      { category: "Databases", items: ["MySQL", "SQL"], order: 4 },
      { category: "Tools", items: ["Git", "GitHub", "VS Code"], order: 5 }
    ]);

    // Seed Education
    await db.insert(education).values({
      degree: "B.Tech in Computer Science & Engineering (Educational Technology)",
      university: "Vellore Institute of Technology, Bhopal",
      duration: "2022 – 2026",
      cgpa: "7.92",
      order: 1
    });

    // Seed Certifications
    await db.insert(certifications).values([
      { name: "AWS Certified Cloud Practitioner", issuer: "AWS" },
      { name: "Oracle OCI Generative AI Professional", issuer: "Oracle" },
      { name: "Accenture AI Fundamentals (ASCEND)", issuer: "Accenture" },
      { name: "Forage: GenAI Data Analytics", issuer: "Forage" },
      { name: "Forage: Solutions Architecture", issuer: "Forage" }
    ]);

    // Seed Achievements
    await db.insert(achievements).values([
      { description: "Top 20 at GrabHack" },
      { description: "Participant: SIH, EY National Challenge, Amazon, Myntra, Adobe, TVS Hackathons" },
      { description: "Student Coordinator — TCS Campus Recruitment" },
      { description: "Vice President — Edu4U Club" }
    ]);

    // Seed Social Links
    await db.insert(socialLinks).values([
      { platform: "LinkedIn", url: "https://www.linkedin.com/in/akarsh-jain-940220252/", icon: "Linkedin" },
      { platform: "GitHub", url: "https://github.com/Jainakarsh27", icon: "Github" },
      { platform: "Email", url: "mailto:contact@akarshjain.dev", icon: "Mail" }
    ]);
  }
}

export const storage = new DatabaseStorage();
