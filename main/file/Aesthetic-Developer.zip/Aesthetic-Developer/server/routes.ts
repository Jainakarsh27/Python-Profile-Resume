import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Seed data on server start (in a real app this might be a separate script or admin action)
  await storage.seedData();

  // API Routes
  app.get(api.profile.get.path, async (req, res) => {
    const profile = await storage.getProfile();
    res.json(profile || {});
  });

  app.get(api.experience.list.path, async (req, res) => {
    const list = await storage.getExperience();
    res.json(list);
  });

  app.get(api.projects.list.path, async (req, res) => {
    const list = await storage.getProjects();
    res.json(list);
  });

  app.get(api.skills.list.path, async (req, res) => {
    const list = await storage.getSkills();
    res.json(list);
  });

  app.get(api.education.list.path, async (req, res) => {
    const list = await storage.getEducation();
    res.json(list);
  });

  app.get(api.certifications.list.path, async (req, res) => {
    const list = await storage.getCertifications();
    res.json(list);
  });

  app.get(api.achievements.list.path, async (req, res) => {
    const list = await storage.getAchievements();
    res.json(list);
  });

  app.get(api.socialLinks.list.path, async (req, res) => {
    const list = await storage.getSocialLinks();
    res.json(list);
  });

  return httpServer;
}
